const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();
disbut = require("discord-buttons");
module.exports = {
  name: "hneko",
  category: "NSFW",
  usage: "[command]",
  run: async (client, message, args) => {
  }
                };