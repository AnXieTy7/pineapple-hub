module.exports = {
    name: "work",
    category: "economy",
  description: "Lets you work a job",
  run: async (client, message, args) => {
  //command
  }
  };