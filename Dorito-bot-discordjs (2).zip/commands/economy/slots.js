module.exports = {
    name: "slots",
    category: "economy",
  description: "lets you play the slot machine",
  run: async (client, message, args) => {
  //command
  }
  };