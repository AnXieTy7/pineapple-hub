module.exports = {
    name: "dice",
    category: "economy",
  description: "Rolls a dice",
  run: async (client, message, args) => {
  //command
  }
  };