module.exports = {
    name: "coinflip",
    category: "economy",
  description: "Flips a coin",
  run: async (client, message, args) => {
  //command
  }
  };