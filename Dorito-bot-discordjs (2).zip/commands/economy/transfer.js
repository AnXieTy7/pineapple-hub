module.exports = {
    name: "transfer",
    category: "economy",
  description: "Lets you transfer money to another user",
  run: async (client, message, args) => {
  //command
  }
  };