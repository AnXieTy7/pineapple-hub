module.exports = {
    name: "daily",
    category: "economy",
  description: "ear your daily cash",
  run: async (client, message, args) => {
  //command
  }
  };