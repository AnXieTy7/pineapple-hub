module.exports = {
    name: "balance",
    category: "economy",
  description: "Lets you check how much money you have",
  run: async (client, message, args) => {
  //command
  }
  };